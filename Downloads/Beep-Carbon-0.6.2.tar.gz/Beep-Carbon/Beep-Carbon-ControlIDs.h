enum {
	mainWindowNotificationsBrowserID = 1001,
	mainWindowAddNotificationID      = 2001, //the '+' button
	mainWindowDeleteNotificationID   = 2002, //the '-' button
	mainWindowUsageStaticTextID      = 3000,
	mainWindowRegisteredCheckboxID   = 3001,
	mainWindowSendButtonID           = 4001
};

enum {
	notificationSheetTitleFieldID      = 1001,
	notificationSheetDescFieldID       = 1002,
	notificationSheetPriorityMenu      = 1003,
	notificationSheetDefaultCheckboxID = 2001,
	notificationSheetStickyID          = 2002,
	notificationSheetIconWellID        = 3001,
	notificationSheetAddButtonID       = 4001,
	notificationSheetCancelButtonID    = 4002
};
