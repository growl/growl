//
//  BeepAdditions.h
//  Beep-Cocoa
//
//  Created by Mac-arena the Bored Zo on 2004-12-06.
//

#import <Cocoa/Cocoa.h>


@interface NSDictionary(BeepAdditions)

- (int)stateForKey:(NSString *)key;

@end
