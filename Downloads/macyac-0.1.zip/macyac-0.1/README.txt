macyac is a client for YAC (yet another caller id), located at http://sunflowerhead.com/software/yac/

This requires the following:

- Landline caller id.
- Requires Mac OS X 10.3
- Requires Growl 0.6
- Requires a windows machine running YAC server.
- Requires caller id service from your telecommunications provider.
- Requires working knowledge of the command line.

Installation:

You may install macyac where ever you like. Preferably you should put it somewhere in the PATH of your shell.

Running macyac:

Usage: ./macyac [-h] [-s] [-p port]
-h: display this help message
-p: port to listen to for incoming Yac messages
-s: make notifications sticky

